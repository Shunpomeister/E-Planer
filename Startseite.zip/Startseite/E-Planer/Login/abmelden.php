<?php
 session_start();
?>
<HTML>
    <head>
    <title></title>
    </head>
<body>
    <?php
        session_unset();
        session_destroy();
        setcookie(session_name(), "", 0, "/");
        header ("Location: Loginseite.php");
    

    ?>