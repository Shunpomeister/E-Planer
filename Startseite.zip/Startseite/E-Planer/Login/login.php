<?php
require_once "login.inc.php";
?>
<HTML>
    <head>
        <meta charset="UTF-8">
    <title></title>
    </head>
    <style>
        body {
            background-color: dimgrey;
            color: whitesmoke;
        }    
        h1  {
           text-align: center;
            }
        .abmelden {
            position: absolute;
            right:1%;
            top: 1%;
        }
        a {
            text-decoration:none;
            color: white;
        }
        table {
			text-align: center;
        }
    </style>
    <body>
        <h1>Willkommen!</h1>   
         <form method="POST" action="abmelden.php">
            <div class="abmelden"><input type="submit" name="Abmelden" value="Abmelden" /></div>
        </form>
        
    
        
    </body>
        
</HTML>