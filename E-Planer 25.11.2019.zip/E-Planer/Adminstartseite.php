<!DOCTYPE html>
<html lang="de" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Startseite</title>
    <style>

      #content	{
        position: absolute;
        left: 2%;
        right: 2%;
        top: 28%;
        height: auto;
        font-size: 20pt;
      }
      #header {
        position: relative;
        width: 100%;
        background-color: #FFA500;
        text-align:center;
      }

      #kalender {
        position: relative;
        top: 10px;
        left: 0%;
        width: 25%;
        background-color: #FFA500;
      }
      #event {
        position: absolute;
        top: 41px;
        left: 25.75%;
        right: 0%;
      }
      img	{
          margin:0px auto;
          width:600px;
          height:180px;
          display: block;
          margin-left: auto;
          margin-right: auto;
        }
      #logout{
        position: absolute;
        right: 10px;
        bottom: 0px;
        text-align: center;
        font-size: 16px;
      }
      #hinzufügen{
        position: absolute;
        right: 50px;
        bottom: 0px;
        text-align: center;
        font-size: 16px;
      }
      #footer	{
        background-color: #FFB732;
        color: #000;
        font-size:12pt;
        position: fixed;
        left: 0px;
        bottom: 0px;
        width: 100%;
        height: 20px;
        text-align:right;
      }

      .eventbox {
        background-color: rgba(0, 0, 0, 0.5);
        color: #FFF;
        font-size:12pt;
        position: relative;

        text-align:left;
        padding: 5px;
      }

      .eventboxwrapper {
        padding-bottom: 10px;
      }
      .eventbilder	{
        width:350px;
        height:220px;
      }
      #bearbeiten{
        position: absolute;
        right: 10px;
        bottom: 0px;
        text-align: center;
        font-size: 16px;
      }

      #löschen {
        position: absolute;
        right: 90px;
        bottom: 0px;
        text-align: center;
        font-size: 16px;
      }
      #hinzufügen {
        position: absolute;
        right: 65px;
        bottom: 0px;
        text-align: center;
        font-size: 16px;
      }
      #löschen{
        position: absolute;
        right: 10px;
        bottom: 0px;
        text-align: center;
        font-size: 16px;
      }
      #bearbeiten {
        position: absolute;
        right: 80px;
        bottom: 0px;
        text-align: center;
        font-size: 16px;
      }
      a {
        color: #FFF;
      }

		</style>
  </head>
  <body style="background-image: url('Images/Paris.jpg');background-size: cover; background-repeat: no repeat; background-attachment: fixed;">
  <a href="Adminstartseite.php"><img src="Images/logo.png"></a>
    <div id="content">

      <div id="header">Admin
        <div id="logout"><a href="Register/Registerseite.php">Logout</a></div>
        <div id="hinzufügen"><a href="hinzufügen.php">Hinzufügen</a></div>
      </div>

      <div id="kalender">kalenderkalenderkalender
        kalenderkalenderkalender
        kalenderkalenderkalender
        kalenderkalenderkalender
        kalenderkalenderkalender</div>

        <div id="event">
                  <?php
                      $pdo = new PDO("mysql: host=localhost; port=3306; charset=utf8; dbname=eplaner","root", "");
                      $sql = "SELECT events.PK_Event_ID, events.Bild, events.Titel, events.Datum_Uhrzeit, events.Ort, events.Beschreibung, events.Straße FROM events";
                      $statement = $pdo->prepare($sql);
                      $statement->execute();

                      while (($record = $statement->fetch(PDO::FETCH_ASSOC)) != FALSE) {

                          echo "<div class=\"eventboxwrapper\">";
                          echo "<div class=\"eventbox\">";
                          ?> <img class="eventbilder" src="<?php echo $record["Bild"];?>"> <?php
                          echo $record["Titel"] . "<br/>";
                          echo date('d.m.Y H:i', strtotime($record["Datum_Uhrzeit"]))."<br/>";
                          echo $record["Ort"] . "<br/>";
                          echo $record["Straße"] . "<br/>";
                          echo $record["Beschreibung"] . "<br/>";
                          echo "<div id=\"löschen\">";
                          echo "<a href=\"loeschen.php?eventid=" . $record["PK_Event_ID"] . "\">Löschen</a>";
                          echo "</div>";
                          echo "<div id=\"bearbeiten\">";
                          echo "<a href=\"bearbeiten.php\">Bearbeiten</a>";
                          echo "</div>";
                          echo "</div>";
                          echo "</div>";
                    }
                 ?>
        </div>
    </div>
    <div id="footer">E-Mail: <a href="mailto:eplaner.hilfe@gmail.com?">eplaner.hilfe@gmail.com</a></div>
  </body>
</html>
