<!DOCTYPE html>
<html>
<title>Kalender</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css.css?<?php echo time(); ?>" type="text/css">
<link rel="stylesheet" href="style.css?<?php echo time(); ?>" type="text/css">


    <script src="jquery.min.js"></script>
<style>
h1,h2,h3,h4,h5,h6 {font-family: "Oswald"}
body {font-family: "Open Sans"}
</style>
      <script>
  $(function() {
    $( "#skills" ).autocomplete({
      source: 'search.php'
    });
  });
  </script>
    <?php include_once('Kalender/functions.php'); ?>
<body>
    <div class="w3-col l12 s12">
      <div class="w3-container w3-white w3-margin w3-padding-large">


          <br>
          <div id="calendar_div">
	<?php echo getCalender(); ?>
</div>



      </div>

    </div>

  </div>

</div>

</body>
</html>
