<html>
<head>
    
    </head>
    <body>
        <?php 

          if (isset($_GET["datum"])) {
            $pdo = new PDO("mysql: host=localhost; charset=utf8; dbname=eplaner","root", "");
            $sql = "SELECT * FROM events WHERE datum = :d";            
            $statement = $pdo->prepare($sql);
            $statement->bindParam(":d", $_GET["datum"]);
            $statement->execute();

            while (($record = $statement->fetch(PDO::FETCH_ASSOC)) != FALSE) {    
              echo $record["Titel"] . "<br/>";
              echo $record["Datum"] . "<br/>";
              echo $record["Beschreibung"] . "<br/>";
            }
          }
    
        ?>
</body>
</html>
