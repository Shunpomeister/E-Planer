<?php
session_start();
require_once "Login/anmelden.inc.php";
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Bearbeiten</title>
</head>
<body>
    <?php
        $dateinameaufderfestplatte = basename($_FILES["bild"]["name"]);
        $bildnameinderdatenbank = "Images/" . $dateinameaufderfestplatte;
        move_uploaded_file($_FILES["bild"]["tmp_name"], $bildnameinderdatenbank);
        $pdo = new PDO("mysql: host=localhost; charset=utf8; dbname=eplaner", "root", "");
        $sql = "UPDATE events SET Titel=\"".$_POST["titel"]."\", Datum=\"".$_POST["datum"]."\", Uhrzeit=\"".$_POST["uhrzeit"]."\", Beschreibung=\"".$_POST["beschreibung"]."\", Straße=\"".$_POST["strasse"]."\", Ort=\"".$_POST["ort"]."\", Bild=:bild WHERE PK_Event_ID=\"".$_POST["id"]."\";";
        $statement = $pdo->prepare($sql);
        $statement->bindParam(":bild", $bildnameinderdatenbank);
        if($statement->execute()) {
            header("Location: adminstartseite.php");
        } else {
            echo "kein Update";
        }
    ?>
</body>
</html>