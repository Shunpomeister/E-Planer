<!DOCTYPE html>
<html lang="de" dir="ltr">
  <head>
    <meta charset="utf-8"/>
    <title>E-Planer</title>
    <style>
    body {
      background-color: #01054C;
    }

      #content	{
        position: relative;
        width: 100%;
        height: auto;
        top: 28%;
        
       
      }
      #header {
        font-size: 15pt;
        position: relative;
        width: 100%;
        background-color: #FFA500;
        text-align:center;
      }

      #kalender {
        font-size: 1.5vw;
        width: 25%;
        background-color: #FFA500;
        text-align: center;
        height: auto;
      }
      #event {
        position: absolute;
        top: 41px;
        left: 25.75%;
        right: 0%;
      }
      img	{
          margin:0px auto;
          width:600px;
          height:180px;
          display: block;
          margin-left: auto;
          margin-right: auto;
        }
      #registerbtn{
        position: absolute;
        right: 10px;
        bottom: 0px;
        text-align: center;
        font-size: 16px;
      }

      #loginbtn {
        position: absolute;
        right: 100px;
        bottom: 0px;
        text-align: center;
        font-size: 16px;
      }

      #footer	{
        background-color: #FFB732;
        color: #000;
        font-size:12pt;
        position: fixed;
        left: 0px;
        bottom: 0px;
        width: 100%;
        height: 20px;
        text-align:right;
      }

      .eventbox {
        background-color: rgba(255, 255, 255, 0.25);
        color: #FFF;
        font-size:12pt;
        position: relative;
        text-align:left;
        padding: 5px;
      }

      .eventboxwrapper {
        padding-bottom: 10px;
      }
      .eventbilder	{
        width:350px;
        height:220px;
      }
      #teilnehmbtn{
        position: absolute;
        right: 10px;
        bottom: 0px;
        text-align: center;
        font-size: 16px;
      }
      a {
        color: #FFF;
        
      }
        .title {
            font-weight: bold;
        }
        td{
            text-align: center;
            background-color: #FF8100;
            width: 14%;;
        }
        th {
            text-align: center;
            width: auto;
            font-weight: bold;
            background-color: white; 
        }
     
        th:nth-of-type(7), td:nth-of-type(7) {
            color: red;
        }
        .heute{
            background-color: green;
        }
        td a{
            display: block;
            width: 100%;
            height: 100%;
            text-decoration: none;
        }
        table{
            table-layout: auto;
            width: 100%;
        }
        .leer{
            background-color: #FFBB40;
        }
		</style>
  </head>
  <body>
  <a href="Startseite.php"><img src="Images/logo.png"></a>
    <div id="content">

      <div id="header">Top Events
        <div id="loginbtn"><a href="Login/Loginseite.php">Login</a></div>
        <div id="registerbtn"><a href="Register/Registerseite.php">Registrieren</a></div>
      </div>

      <div id="kalender">
        
        
        <?php
        date_default_timezone_set('Europe/Vienna');
        setlocale(LC_TIME, "de_DE");

        if (isset($_GET['ym'])) {
            $ym = $_GET['ym'];
        } else {
            $ym = date('Y-m');
        }

        if (isset($_GET['ym'])) {
            $ym = $_GET['ym'];
        } else {
            $ym = date('Y-m');
        }

        $timestamp = strtotime($ym . '-01');
        if ($timestamp === false) {
            $ym = date('Y-m');
            $timestamp = strtotime($ym . '-01');

        }

        $heute = date('Y-m-d');
        $title = strftime('%B, %Y', $timestamp);
        
        $prev = date('Y-m', strtotime('-1 month', $timestamp));
        $next = date('Y-m', strtotime('+1 month', $timestamp));
        
      
        //anzahl der Tage im Monat
        $mtage = date("t", $timestamp);

        //erster Tag des Monats
        $fdm = date( 'N', $timestamp)- 1;
        
    ?>
    
            <a href="?ym=<?= $prev; $prevday;?>" class="btn-link">&#8678;prev</a>
            <span class="title"><?= $title; ?></span>
            <a href="?ym=<?= $next; $nextday;?>" class="btn-link">next&#8680;</a>
          <div id="Tabelle">
    <table>
        <tr>
            <th>Mo</th>
            <th>Di</th>
            <th>Mi</th>
            <th>Do</th>
            <th>Fr</th>
            <th>Sa</th>
            <th>So</th>
        </tr>
        <tr>
        <?php
            // leere Zellen Anfang
            for ($tag = 0; $tag < $fdm; $tag += 1) {
                echo "<td class='leer'>&nbsp;</td>";
            }
            // tage
            for ($tag = 1; $tag <= $mtage; $tag += 1) {
                $datum = $ym . '-' . $tag;
                if ($heute == $datum) {
                    $woche= '<td class="heute">';
                } else {
                    $woche= '<td>';
                }
                echo $woche."<a href='?datum=".$datum."'>".$tag.
                    "</a></td>";
                if ( ($fdm + $tag) % 7 == 0) {
                    echo "</tr>\n<tr>";
                }
            }
            // zellen am Ende
            $fill = (7-($fdm + $mtage)%7);
            for ($tag = 0; $tag < $fill; $tag+=1){
                echo "<td class='leer'>&nbsp;</td>";
            }
            
        ?>
          </table>
              </div>
        </div>

        <div id="event">
                  <?php
                      
                    if (isset($_GET["datum"])) {
                        $pdo = new PDO("mysql: host=localhost; charset=utf8; dbname=eplaner","root", "");
                        $sql = "SELECT * FROM events WHERE datum = :d";            
                        $statement = $pdo->prepare($sql);
                        $statement->bindParam(":d", $_GET["datum"]);
                        $statement->execute();
                      while (($record = $statement->fetch(PDO::FETCH_ASSOC)) != FALSE) {

                          echo "<div class=\"eventboxwrapper\">";
                          echo "<div class=\"eventbox\">";
                          ?> <img class="eventbilder" src="<?php echo $record["Bild"];?>"> <?php
                          echo $record["Titel"] . "<br/>";
                          echo $record["Ort"] . "<br/>";
                          echo $record["Straße"] . "<br/>";
                          echo date('d.m.Y H:i', strtotime($record["Datum"] . $record["Uhrzeit"]))."<br/>";
                          echo "<div id=\"teilnehmbtn\">";
                          echo "für mehr infos bitte anmelden";
                          echo "</div>";
                          echo "</div>";
                          echo "</div>";
                    }           
                    }else {
                        $pdo = new PDO("mysql: host=localhost; port=3306; charset=utf8; dbname=eplaner","root", "");
                      $sql = "SELECT Bild, Titel, Datum, Uhrzeit, Beschreibung, Ort, Straße FROM events;";
                      $statement = $pdo->prepare($sql);
                      $statement->execute();
                        while (($record = $statement->fetch(PDO::FETCH_ASSOC)) != FALSE) {

                          echo "<div class=\"eventboxwrapper\">";
                          echo "<div class=\"eventbox\">";
                          ?> <img class="eventbilder" src="<?php echo $record["Bild"];?>"> <?php
                          echo $record["Titel"] . "<br/>";
                          echo $record["Ort"] . "<br/>";
                          echo $record["Straße"] . "<br/>";
                          echo date('d.m.Y H:i', strtotime($record["Datum"] . $record["Uhrzeit"]))."<br/>";
                          echo "<div id=\"teilnehmbtn\">";
                          echo "für mehr infos bitte anmelden";
                          echo "</div>";
                          echo "</div>";
                          echo "</div>";
                    }           
                    }
                 ?>
        </div>
    </div>
    <div id="footer">E-Mail: <a href="mailto:eplaner.hilfe@gmail.com?">eplaner.hilfe@gmail.com</a></div>
  </body>
</html>
