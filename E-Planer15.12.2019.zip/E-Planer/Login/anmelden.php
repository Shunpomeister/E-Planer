<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Anmelden</title>
</head>
<body>
    <?php
        if(isset($_POST["benutzername"]) && isset($_POST["passwort"])) {
            $benutzername = $_POST["benutzername"];
            $passwort = $_POST["passwort"];

            $pdo = new PDO("mysql: host=localhost; dbname=eplaner", "root", "");
            $sql = "SELECT * FROM benutzer WHERE Benutzername = :benutzername AND Passwort = :passwort;";
            $statement = $pdo->prepare($sql);
            $statement->bindParam(":benutzername", $benutzername);
            $statement->bindParam(":passwort", $passwort);

                if($statement->execute()) {

                    if(($admin = $statement->fetch(PDO::FETCH_ASSOC)) != FALSE) {
                        $_SESSION["logged_in"] = true;
                        $_SESSION["PK_Benutzer_ID"] = $admin["PK_Benutzer_ID"];
                        if(($admin["FK_Rechte_ID"]) == "1") {
                            header("Location: ../Adminstartseite.php");
                        } else {
                            header("Location: ../Userstartseite.php");
                        }
                    } else {
                        $_SESSION["logged_in"] = false;
                        header("Location: Loginseite.php");
                    }
                }
        } else {
            echo "Es wurde weder Username noch Password geschickt!";
        }
    ?>
</body>
</html>
