<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="utf-8">
    <title>PHP Calendar</title>

    <style>
        .container {
            font-family: 'Montserrat', sans-serif;
            
        }
        
        .title {
            font-weight: bold;
            font-size: 22px;
        }
        td{
            text-align: center;
        }
        th {
            text-align: center;
        }
     
        th:nth-of-type(7), td:nth-of-type(7) {
            color: red;
        }
        .heute{
            background-color: green;
        }
        
    </style>
</head>
<body>
    
    <?php
        date_default_timezone_set('Europe/Vienna');
        setlocale(LC_TIME, "de_DE");

        if (isset($_GET['ym'])) {
            $ym = $_GET['ym'];
        } else {
            $ym = date('Y-m');
        }

        if (isset($_GET['ym'])) {
            $ym = $_GET['ym'];
        } else {
            $ym = date('Y-m');
        }

        $timestamp = strtotime($ym . '-01');
        if ($timestamp === false) {
            $ym = date('Y-m');
            $timestamp = strtotime($ym . '-01');

        }

        $heute = date('Y-m-d');
        $title = strftime('%B, %Y', $timestamp);
        
        $prev = date('Y-m', strtotime('-1 month', $timestamp));
        $next = date('Y-m', strtotime('+1 month', $timestamp));
        
      
        //anzahl der Tage im Monat
        $mtage = date("t", $timestamp);

        //erster Tag des Monats
        $fdm = date( 'N', $timestamp)- 1;
        
    ?>
    <div class="container">
            <a href="?ym=<?= $prev; $prevday;?>" class="btn-link">vorher</a>
            <span class="title"><?= $title; ?></span>
            <a href="?ym=<?= $next; $nextday;?>" class="btn-link">nächster</a>
  
    <table>
        <tr>
            <th>Mo</th>
            <th>Di</th>
            <th>Mi</th>
            <th>Do</th>
            <th>Fr</th>
            <th>Sa</th>
            <th>So</th>
        </tr>
        <tr>
        <?php
            // leere Zellen Anfang
            for ($tag = 0; $tag < $fdm; $tag += 1) {
                echo "<td>&nbsp;</td>";
            }
            // tage
            for ($tag = 1; $tag <= $mtage; $tag += 1) {
                $datum = $ym . '-' . $tag;
                if ($heute == $datum) {
                    $woche= '<td class="heute">';
                } else {
                    $woche= '<td>';
                }
                echo $woche."<a href='verbindung.php?datum=".$datum."'>".$tag.
                    "</a></td>";
                if ( ($fdm + $tag) % 7 == 0) {
                    echo "</tr>\n<tr>";
                }
            }
            // zellen am Ende
            $fill = (7-($fdm + $mtage)%7);
            for ($tag = 0; $tag < $fill; $tag+=1){
                echo "<td>&nbsp;</td>";
            }
            
        ?>
        </tr>
    </table>
    </div>
</body>
</html>