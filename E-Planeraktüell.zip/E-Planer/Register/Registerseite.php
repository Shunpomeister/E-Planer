<!DOCTYPE html>
<html lang="de" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Registrierung</title>
    <style>
    img	{
        margin:0px auto;
        width:600px;
        height:180px;
        display: block;
        margin-left: auto;
        margin-right: auto;
      }
	#register	{
      position: absolute;
  		left: 50%;
  		margin-top: -125px;
  		margin-left: -125px;
  		top: 50%;
  		width:250px;
  		height:450px;
  		background-color:#FFEFEF;
  		border:solid 2px;
      text-align:center;
      font-family: cursive;
		}
  #formular	{
      position: absolute;
      left: 10px;
      top: 50px;
      right: 10px;
      bottom: 10px;
      background-color:#FFEFEF;
      border:solid 2px;
      text-align:center;
    }
  #footer	{
        background-color: #FFB732;
        color: #000;
        font-size:12pt;
        position: fixed;
        left: 0px;
        bottom: 0px;
        width: 100%;
        height: 20px;
        text-align:right;
  	}
		</style>
  </head>


  <body style="background-image: url('../Images/Paris.jpg');background-size: cover; background-repeat: no repeat; background-attachment: fixed;">
    <a href="../Startseite.php"><img src="../Images/logo.png"></a>
	<?php
				header('Content-Type: text/html; charset=UTF-8');

				$firma = new PDO("mysql: host=localhost; dbname=eplaner", "root");

	?>

    <div id="register"><br/>
	Registrieren

    <div id="formular">

	<form method="POST">
			<br/>
			<p>
			Benutzername:
			<input type ="text" size="17" name="user"/> <br/>
			<br/>
			Geburtsdatum:
			<input id="date" type="date" name="geb" size="17" value="JJJJ-MM-TT"> <br/>
			<br/>
			Geschlecht:
			<br/>
			<select name="geschlecht">
			<?php
				$sql_statement = "SELECT * FROM geschlecht;";
				$command = $firma->prepare($sql_statement);
				$command->execute();

				while(($record =  $command->fetch(PDO::FETCH_ASSOC)) != FALSE) {

					echo '<option value="' . $record["PK_Geschlecht_ID"]. '">' . $record["Geschlecht"]. '</option>';
				}
			?>
			</select>
			<br/>
			<br/>
			Passwort:
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="password" name="passwort" size="17" id="myInput" maxlength="40" required>
			<input type="checkbox" onclick="myFunction()">

			<script>
			function myFunction() {
				var x = document.getElementById("myInput");
				if (x.type === "password") {
					x.type = "text";
				} else {
					x.type = "password";
				}
			}
			</script>
			<br/>
			<br/>
			<input type ="submit" name="login" value="Speichern" style="background-color:#888888; color: white; width:100px; height:30px;"/>
		</form>

	</div></div>
	 <?php
                    if (isset($_POST["login"])){
                        $statement = $pdo->prepare("INSERT INTO benutzer(Benutzername,Geburtsdatum,Geschlecht,Passwort) VALUES(:user,:geb,:geschlecht,:Passwort);");
                        $statement->bindParam(":user",$_POST["user"]);
                        $statement->bindParam(":geb",$_POST["geb"]);
                        $statement->bindParam(":geschlecht",$_POST["geschlecht"]);
                        $statement->bindParam(":Passowrt",$_POST["passwort"]);
                        $statement->execute();
                        //$statement->debugDumpParams();

                    }

                ?>
    <div id="footer">Kontakt: Tel./Nr.: +436604337890 / E-Mail: <a href="mailto:Eplaner.hilfe@gmail.com?">eplaner.hilfe@gmail.com</a></div>
  </body>
</html>
