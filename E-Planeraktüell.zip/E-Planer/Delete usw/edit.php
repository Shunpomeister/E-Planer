<!DOCTYPE html>
<html lang="de" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Bearbeiten</title>

  </head>
  <body>
<?php

	$id = $_POST['id'];
	$title = $_POST['title'];
	$date = $_POST['date'];
	$description = $_POST['description'];
	
	$pdo = new PDO("mysql: host=localhost; dbname=eplaner;charset=utf8","root", "");
	$statement = $pdo->prepare("UPDATE events SET Titel =".$title.",Datum =".$date.", Beschreibung =".$description." WHERE PK_Event_ID = $id");
	$statement->execute();
	
	header("refresh:1; url=edit_index.php");
?>

  
  
  </body>
</html>