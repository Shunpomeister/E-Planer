<!DOCTYPE html>
<html lang="de" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>E-Planer</title>
    <style>

      #content	{
        position: absolute;
        left: 2%;
        right: 2%;
        top: 28%;
        height: auto;
        font-size: 20pt;
      }
      #header {
        position: relative;
        width: 100%;
        background-color: #FFA500;
        text-align:center;
      }
      img	{
          margin:0px auto;
          width:600px;
          height:180px;
          display: block;
          margin-left: auto;
          margin-right: auto;
        }
      #logout{
        position: absolute;
        right: 10px;
        bottom: 0px;
        text-align: center;
        font-size: 16px;
      }

      #hinzufügen {
        position: absolute;
        right: 75px;
        bottom: 0px;
        text-align: center;
        font-size: 16px;
      }
      #formular {
        position: relative;
        width: 25%;
		left:35%;
        top: 30px;
        text-align: center;
        background-color: #FFA500;
      	background-color:#FFA500;
      	border-radius:40px;
      	border:2px solid #FFA500;
      	display:inline-block;
      	color:#FFF;
      	padding:17px 30px;
      	text-decoration:none;
      	text-shadow:0px 1px 12px #2f6627;
      }
      .textfeld {
      	background-color:#FFA500;
      	border-radius:40px;
      	border:2px solid #FFF;
      	display:inline-block;
      	color:#FFF;
      	font-family:Verdana;
      	font-size:14px;
      	font-weight:bold;
      	padding:6px 12px;
      }
      .beschreibung {
      	background-color:#FFA500;
      	border-radius:40px;
      	border:2px solid #FFF;
      	display:inline-block;
      	color:#FFF;
      	font-family:Verdana;
      	font-size:14px;
      	font-weight:bold;
      	padding:6px 12px;
        height: 100px;
        width: 330px;
      }
      .btn {
      	background-color:#FFA500;
      	border-radius:40px;
      	border:2px solid #FFF;
      	display:inline-block;
      	color:#FFF;
      	font-family:Verdana;
      	font-size:12px;
      	font-weight:bold;
      	padding:13px 22px;
      	text-shadow:0px 1px 12px #2F6627;
      	cursor:pointer;
      }
		</style>
  </head>
  <body style="background-image: url('Images/Paris.jpg');background-size: cover; background-repeat: no repeat; background-attachment: fixed;">
  <a href="Adminstartseite.php"><img src="Images/logo.png"></a>
    <div id="content">
      <div id="header">Event hinzufügen
        <div id="logout"><a href="Startseite.php">Logout</a></div>
        <div id="hinzufügen"><a href="Adminstartseite.php">Events</a></div>
      </div>


      <div id="formular">
        <?php
          if (isset($_POST["hinz"])) {

            if (!empty($_POST["titel"]) && !empty($_POST["datum"]) && !empty($_POST["beschreibung"]) && !empty($_POST["bild"])) {

              $pdo = new PDO("mysql: host=localhost; port=3306; charset=utf8; dbname=eplaner","root", "");
              $sql = "INSERT INTO `events`(`Titel`, `Datum_Uhrzeit`, `Beschreibung`, `Bild`, `Webseite`) VALUES(:titel, :datum, :beschreibung, :bild, :webseite)";
              $statement = $pdo->prepare($sql);
              $statement->bindParam(":titel", $_POST["titel"]);
              $statement->bindParam(":datum", $_POST["datum"]);
              $statement->bindParam(":beschreibung", $_POST["beschreibung"]);
			  $statement->bindParam(":webseite", $_POST["webseite"]);
              $statement->bindParam(":bild", $_POST["bild"]);
			  
              $statement->execute();

            } else {

              echo "Bitte versuchen Sie es nocheinmal!";
            }
          }
       ?>
       <form action="Hinzufügen.php" method="POST" >
           <input type="hidden" name="id" value="$_GET['id']"/>
             Titel:</br>
             <input type="text" name="titel" size="22" class="textfeld"/> </br></br>
             Datum & Uhrzeit:</br>
             <input type="datetime-local" name="datum" class="textfeld"/> </br></br>
             Beschreibung:</br>
             <input type="text"name="beschreibung" class="beschreibung"/> </br></br>
			 Link zur Webseite:</br>
             <input type="text" name="webseite" size="35"  class="textfeld"/> </br></br>
             Bild:</br>
             <input type="file" name="bild" class="textfeld"/> </br></br>
             <input type ="submit" name="hinz" value="Speichern" class="btn"/>
       </form>

  	  </div>
    </div>
  </body>
</html>
