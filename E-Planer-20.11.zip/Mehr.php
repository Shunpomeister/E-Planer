
<html lang="de" dir="ltr">
	<head>
		<title>Details</title>
		<meta charset="UTF-8">
		<style>

      #content	{
        position: absolute;
        left: 2%;
        right: 2%;
        top: 28%;
        height: auto;
        font-size: 20pt;
      }
      #header {
        position: relative;
        width:89%;
		left: 6%;
        background-color: #FFA500;
        text-align:center;
      }
      img	{
          margin:0px auto;
          width:600px;
          height:180px;
          display: block;
          margin-left: auto;
          margin-right: auto;
        }
      #logout{
        position: absolute;
        right: 10px;
        bottom: 0px;
        text-align: center;
        font-size: 16px;
      }

      #hinzufügen {
        position: absolute;
        right: 75px;
        bottom: 0px;
        text-align: center;
        font-size: 16px;
      }
	  #image {
        position: absolute;
        left: 25px;
        top: 25px;
      }
      #details {
        position: relative;
        width: 85%;
		left:6%;
        top: 30px;
        background-color: #FFA500;
      	background-color:#FFA500;
      	border-radius:40px;
      	border:2px solid #FFA500;
      	display:inline-block;
      	color:#FFF;
      	padding:217px 30px;
      	text-decoration:none;
      	text-shadow:0px 1px 12px #2f6627;
      }
      .textfeld {
      	background-color:#FFA500;
      	border-radius:40px;
      	border:2px solid #FFF;
      	display:inline-block;
      	color:#FFF;
      	font-family:Verdana;
      	font-size:14px;
      	font-weight:bold;
      	padding:6px 12px;
      }
      .beschreibung {
      	background-color:#FFA500;
      	border-radius:40px;
      	border:2px solid #FFF;
      	display:inline-block;
      	color:#FFF;
      	font-family:Verdana;
      	font-size:14px;
      	font-weight:bold;
      	padding:6px 12px;
        height: 100px;
        width: 330px;
      }
      .btn {
      	background-color:#FFA500;
      	border-radius:40px;
      	border:2px solid #FFF;
      	display:inline-block;
      	color:#FFF;
      	font-family:Verdana;
      	font-size:12px;
      	font-weight:bold;
      	padding:13px 22px;
      	text-shadow:0px 1px 12px #2F6627;
      	cursor:pointer;
      }
		</style>
	</head>
		<body>
		 <body style="background-image: url('Images/Paris.jpg');background-size: cover; background-repeat: no repeat; background-attachment: fixed;">
  <a href="Adminstartseite.php"><img src="Images/logo.png"></a>
    <div id="content">
      <div id="header">Details
        <div id="logout"><a href="Startseite.php">Logout</a></div>
        <div id="hinzufügen"><a href="Userstartseite.php">Events</a></div>
      </div>
	  
	  <div id="details">
	  <div id="image">
	  <img src="Images/2.jpg" /> </div>
		<?php
			
		
		$pdo = new PDO("mysql: host=localhost; dbname=eplaner;charset=utf8","root", "");
		$statement = $pdo->prepare("SELECT * FROM events WHERE PK_Event_ID = :eventid");
		$statement->bindParam(":eventid" , $_GET["eventid"]);
		$statement->execute();
		
		$statement2 = $pdo->prepare("SELECT Webseite FROM events WHERE Webseite IS NOT NULL AND PK_Event_ID = :eventid;");
		$statement2->bindParam(":eventid" , $_GET["eventid"]);
		$statement2->execute();
		
				while (($record = $statement->fetch(PDO::FETCH_ASSOC)) != FALSE) {
					echo "Titel:&nbsp;&nbsp;&nbsp;" . $record['Titel']."</br></br>";
					echo "Ort:&nbsp;&nbsp;&nbsp;" . $record['FK_Ort_ID']."</br></br>";
					echo "Datum und Uhrzeit:&nbsp;&nbsp;&nbsp;" . $record['Datum_Uhrzeit']."</br></br>";
					echo "Beschreibung: </br>" .  $record['Beschreibung']."</br></br>";
					
				if (($record = $statement2->fetch(PDO::FETCH_ASSOC)) != FALSE) {
					echo "Für mehr infos hier zur Homepage:"."</br>";
					echo "<a href=https://".$record['Webseite']."> Webseite </a></br>";
					
				}
				else {
				echo "Für mehr infos hier zur Homepage:"."</br>";
				echo "Der Veranstallter verfügt derzeit über keine Webseite";
				}
					echo "</br>";
				}
					
			?>					
				


		
					
  </body>
</html>