<!DOCTYPE html>
<html lang="de" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>E-Planer</title>
    <style>

      #content	{
        position: absolute;
        left: 2%;
        right: 2%;
        top: 28%;
        height: auto;
        font-size: 20pt;
      }
      #header {
        position: relative;
        width: 100%;
        background-color: #FFA500;
        text-align:center;
      }
      img	{
          margin:0px auto;
          width:600px;
          height:180px;
          display: block;
          margin-left: auto;
          margin-right: auto;
        }
      #logout{
        position: absolute;
        right: 10px;
        bottom: 0px;
        text-align: center;
        font-size: 16px;
      }

      #hinzufügen {
        position: absolute;
        right: 75px;
        bottom: 0px;
        text-align: center;
        font-size: 16px;
      }
      #formular {
        position: relative;
        width: 25%;
		left:35%;
        top: 30px;
        text-align: center;
        background-color: #FFA500;
      	background-color:#FFA500;
      	border-radius:40px;
      	border:2px solid #FFA500;
      	display:inline-block;
      	color:#FFF;
      	padding:17px 30px;
      	text-decoration:none;
      	text-shadow:0px 1px 12px #2f6627;
      }
      .textfeld {
      	background-color:#FFA500;
      	border-radius:40px;
      	border:2px solid #FFF;
      	display:inline-block;
      	color:#FFF;
      	font-family:Verdana;
      	font-size:14px;
      	font-weight:bold;
      	padding:6px 12px;
      }
      .beschreibung {
      	background-color:#FFA500;
      	border-radius:40px;
      	border:2px solid #FFF;
      	display:inline-block;
      	color:#FFF;
      	font-family:Verdana;
      	font-size:14px;
      	font-weight:bold;
      	padding:6px 12px;
        height: 100px;
        width: 330px;
      }
      .btn {
      	background-color:#FFA500;
      	border-radius:40px;
      	border:2px solid #FFF;
      	display:inline-block;
      	color:#FFF;
      	font-family:Verdana;
      	font-size:12px;
      	font-weight:bold;
      	padding:13px 22px;
      	text-shadow:0px 1px 12px #2F6627;
      	cursor:pointer;
      }
		</style>
  </head>
  <body style="background-image: url('Paris.jpg');background-size: cover; background-repeat: no repeat; background-attachment: fixed;">
  <a href="Adminstartseite.php"><img src="..\Images/logo.png"></a>
  	<?php
				header('Content-Type: text/html; charset=UTF-8');

				$firma = new PDO("mysql: host=localhost; charset=utf8; dbname=eplaner", "root");

	?>
	<div id="content">
      <div id="header">Registrieren
        <div id="logout"><a href="Register/Registerseite.php">Logout</a></div>
        <div id="hinzufügen"><a href="Adminstartseite.php">Events</a></div>
      </div>


      <div id="formular">
        <?php


            if (!empty($_POST["user"]) && !empty($_POST["geb"]) && !empty($_POST["geschlecht"]) && !empty($_POST["passwort"])) {

              $pdo = new PDO("mysql: host=localhost; port=3306; charset=utf8; dbname=eplaner","root", "");
					$sql ="INSERT INTO benutzer(Benutzername,Geburtsdatum,Geschlecht,Passwort) VALUES(:user,:geb,:geschlecht,:Passwort)";
					$statement = $pdo->prepare($sql);
					$statement->bindParam(":user",$_POST["user"]);
					$statement->bindParam(":geb",$_POST["geb"]);
					$statement->bindParam(":geschlecht",$_POST["geschlecht"]);
					$statement->bindParam(":Passowrt",$_POST["passwort"]);
					$statement->execute();
			  

            } else {

              echo "Bitte versuchen Sie es nocheinmal!";
            }
          
       ?>
       <form method="POST">
			<br/>
			<p>
			Benutzername:
			<input type ="text" size="17" name="user"/> <br/>
			<br/>
			Geburtsdatum:
			<input id="date" type="date" name="geb" size="17" value="JJJJ-MM-TT"> <br/>
			<br/>
			Geschlecht:
			
			<select name="geschlecht">
			<?php
				$sql_statement = "SELECT * FROM geschlecht;";
				$command = $firma->prepare($sql_statement);
				$command->execute();

				while(($record =  $command->fetch(PDO::FETCH_ASSOC)) != FALSE) {

					echo '<option value="' . $record["PK_Geschlecht_ID"]. '">' . $record["Geschlecht"]. '</option>';
				}
			?>
			</select>
			<br/>
			<br/>
			Passwort:
			&nbsp;&nbsp;<input type="password" name="passwort" size="17" id="myInput" maxlength="40" required>
			<input type="checkbox" onclick="myFunction()">

			<script>
			function myFunction() {
				var x = document.getElementById("myInput");
				if (x.type === "password") {
					x.type = "text";
				} else {
					x.type = "password";
				}
			}
			</script>
			<br/>
			<br/>
			<input type ="submit" name="hinz" value="Registrieren" class="btn"/>
		</form>

  	  </div>
    </div>
  </body>
</html>
