<!DOCTYPE html>
<html lang="de" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Registrierung</title>
    <style>
 #logo	{
		margin:0px auto;
		width:0px;
		height:0px;
		background-color:#FFF;
		float: left;
		width: 50%;
		top: 0px;

    }
	#bearbeiten	{
      position: absolute;
  		left: 35%;
		 margin-top: -105px;
  		margin-left: -105px;
  		top: 30%;
  		width:37%;
  		height:650px;
  		background-color:#FFEFEF;
  		border:solid 2px;
      font-family: cursive;
		}
  #formular	{
      position: absolute;
      left: 10px;
      top: 84px;
      right: 10px;
      bottom: 10px;
      background-color:#FFEFEF;
      border:solid 2px;
    }
  #footer	{
        background-color: #FFB732;
        color: #000;
        font-size:12pt;
        position: fixed;
        left: 0px;
        bottom: 0px;
        width: 100%;
        height: 20px;
        text-align:right;
  	}
		</style>
  </head>
    <div id="logo"><a href="../../Startseite.php"><img src="../../Images/logo.png"></a></div>

  <body style="background-image: url('../../Images/Paris.jpg');background-size: cover; background-repeat: no repeat; background-attachment: fixed;">


    <div id="bearbeiten"><br/>
	<h1> &nbsp;Event bearbeiten</h1>

    <div id="formular">

	<form action="edit.php" method="post" >
	<input type="hidden" name="id" value="$_GET['id']"/>
			<br/>
			<p>
		&nbsp;Titel:</br>
		&nbsp;<input type="text" name="title" /> </br></br>
		&nbsp;Datum:</br>
		&nbsp;<input type="date" name="date"  /> </br></br>
		&nbsp;Beschreibung:</br>
		&nbsp;<input type="text" style="height: 100px;" name="description" size="90"  /> </br></br>
		&nbsp;Bild:</br>
		&nbsp;<input name="uploaded" type="file" id="uploaded" size="50"  /> </br></br>
		</br>
		&nbsp;&nbsp;<input type ="submit" name="hinz" value="Speichern"/>
		</form>

	</div></div>
	 <?php
                    if (isset($_POST["login"])){
                        $statement = $pdo->prepare("INSERT INTO benutzer(Benutzername,Geburtsdatum,Geschlecht,Passwort) VALUES(:user,:geb,:geschlecht,:Passwort);");
                        $statement->bindParam(":user",$_POST["user"]);
                        $statement->bindParam(":geb",$_POST["geb"]);
                        $statement->bindParam(":geschlecht",$_POST["geschlecht"]);
                        $statement->bindParam(":Passowrt",$_POST["passwort"]);
                        $statement->execute();
                        //$statement->debugDumpParams();

                    }

                ?>
    <div id="footer">Kontakt: Tel./Nr.: +436604337890 / E-Mail: <a href="mailto:Eplaner.hilfe@gmail.com?">eplaner.hilfe@gmail.com</a></div>
  </body>
</html>
