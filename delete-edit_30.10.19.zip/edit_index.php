<html lang="de" dir="ltr">
	<head>
		<title>Events</title>
		<meta charset="UTF-8">
	</head>
		<body>
		<form action="edit.php" method="post" >
		<input type="hidden" name="id" value="$_GET['id']"/>
		Titel:
		<input type="text" name="title" /> </br></br>
		Datum:
		<input type="date" name="date"  /> </br></br>
		Beschreibung:
		<input type="text" name="description" size="60"  /> </br></br>
		Bild:
		<input name="uploaded" type="file" id="uploaded" size="50"  /> </br></br>
		
		<input type ="submit" name="hinz" value="Speichern"/>
		</form>			
  </body>
</html>