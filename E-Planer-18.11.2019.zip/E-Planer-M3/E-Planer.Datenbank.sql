﻿DROP DATABASE IF EXISTS eplaner;
CREATE DATABASE eplaner CHARACTER SET utf8 COLLATE utf8_general_ci;
USE eplaner;

CREATE TABLE geschlecht (
	PK_Geschlecht_ID int NOT NULL PRIMARY KEY, 
	Geschlecht VARCHAR(255)
);

INSERT INTO geschlecht (PK_Geschlecht_ID, Geschlecht) VALUES ("1", "mänlich");
INSERT INTO geschlecht (PK_Geschlecht_ID, Geschlecht) VALUES ("2", "weiblich");


CREATE TABLE rechte (
	PK_Rechte_ID int NOT NULL PRIMARY KEY, 
	Rechte VARCHAR(255)
);

INSERT INTO rechte (PK_Rechte_ID, Rechte) VALUES ("1", "Darf im Backend");
INSERT INTO rechte (PK_Rechte_ID, Rechte) VALUES ("2", "Darf nicht im Backend");


CREATE TABLE ort (
	PK_Ort_ID int AUTO_INCREMENT NOT NULL PRIMARY KEY, 
	Ort VARCHAR(255),
	PLZ int,
	Adresse VARCHAR(255)
);

INSERT INTO ort (Ort, PLZ, Adresse) VALUES ("Wien", "1020", "Praterstrasse");
INSERT INTO ort (Ort, PLZ, Adresse) VALUES ("Schwechat", "2320", "Himbergerstraße");


CREATE TABLE events (
	PK_Event_ID int AUTO_INCREMENT NOT NULL PRIMARY KEY,
	Titel VARCHAR(255),
	Datum_Uhrzeit DATETIME,
	Beschreibung VARCHAR(1500),
	Bild VARCHAR(255),
	FK_Ort_ID int,
	FOREIGN KEY (FK_Ort_ID) REFERENCES ort(PK_Ort_ID)
);

INSERT INTO events (Titel, Datum_Uhrzeit, Beschreibung, Bild, FK_Ort_ID) VALUES ("Paintball Event", "2019-06-20 16:30:00", "Wir gehen Paintball spielen am 20.06.2019, alle unter 16 Jährigen brauchen die Erlaubnis ihrer Eltern.", "funktioniert noch nicht", "1");
INSERT INTO events (Titel, Datum_Uhrzeit, Beschreibung, Bild, FK_Ort_ID) VALUES ("Predrag mobben", "2020-11-23 15:00:00", "Nerv nd Predrag", "funktioniert noch nicht", "2");


CREATE TABLE benutzer (
	PK_Benutzer_ID int AUTO_INCREMENT NOT NULL PRIMARY KEY, 
	Benutzername VARCHAR(255), 
	Passwort VARCHAR(255), 
	Geburtsdatum DATE, 
	FK_Geschlecht_ID int,
	FOREIGN KEY (FK_Geschlecht_ID) REFERENCES geschlecht(PK_Geschlecht_ID), 
	FK_Rechte_ID int,
	FOREIGN KEY (FK_Rechte_ID) REFERENCES rechte(PK_Rechte_ID),
	FK_Event_ID int,
	FOREIGN KEY (FK_Event_ID) REFERENCES events(PK_Event_ID)
);

INSERT INTO benutzer (Benutzername, Passwort, Geburtsdatum, FK_Geschlecht_ID, FK_Rechte_ID, FK_Event_ID) VALUES ("admin", "admin", "1990-01-01", "1", "1", "1");
INSERT INTO benutzer (Benutzername, Passwort, Geburtsdatum, FK_Geschlecht_ID, FK_Rechte_ID, FK_Event_ID) VALUES ("TestUser", "test", "2019-10-02", "1", "2", "1");