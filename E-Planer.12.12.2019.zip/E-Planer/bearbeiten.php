<?php
session_start();
require_once "Login/anmelden.inc.php";
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Bearbeiten</title>
</head>
<body>
  <?php
      $pdo = new PDO("mysql: host=localhost; charset=utf8; dbname=eplaner", "root", "");
      $sql = "SELECT * FROM events";
      $statement = $pdo->prepare($sql);
      $statement->execute();
  ?>
<table>
  <tr>
    <th>Titel</th>
    <th>Datum</th>
    <th>Uhrzeit</th>
    <th>Beschreibung</th>
    <th>Straße</th>
    <th>Ort</th>
  </tr>
  <?php
      while (($record = $statement->fetch(PDO::FETCH_ASSOC)) != FALSE) {
        echo "<tr><form action=\"update.php\" method=\"POST\">";
        echo "<td><input type=\"text\" name=\"titel\" value=\"".$record["Titel"]."\"</td>";
        echo "<td><input type=\"date\" name=\"datum\" value=\"".$record["Datum"]."\"</td>";
        echo "<td><input type=\"time\" name=\"uhrzeit\" value=\"".$record["Uhrzeit"]."\"</td>";
        echo "<td><input type=\"text\" name=\"beschreibung\" value=\"".$record["Beschreibung"]."\"</td>";
        echo "<td><input type=\"text\" name=\"strasse\" value=\"".$record["Straße"]."\"</td>";
        echo "<td><input type=\"text\" name=\"ort\" value=\"".$record["Ort"]."\"</td>";
        echo "<td><input type=\"file\" name=\"bild\" value=\"".$record["Bild"]."\"</td>";
        echo "<input type=\"hidden\" name=\"id\" value=\"".$record["PK_Event_ID"]."\"";
        echo "<td><input type=\"submit\"></td>";
        echo "</form></tr>";
      }
    ?>
</table>
</body>
</html>