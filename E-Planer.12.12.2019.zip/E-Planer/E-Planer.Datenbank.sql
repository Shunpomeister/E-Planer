﻿DROP DATABASE IF EXISTS eplaner;
CREATE DATABASE IF NOT EXISTS eplaner CHARACTER SET utf8 COLLATE utf8_general_ci;
USE eplaner;

CREATE TABLE geschlecht (
	PK_Geschlecht_ID int NOT NULL PRIMARY KEY, 
	Geschlecht VARCHAR(255)
);

INSERT INTO geschlecht (PK_Geschlecht_ID, Geschlecht) VALUES ("1", "Männlich");
INSERT INTO geschlecht (PK_Geschlecht_ID, Geschlecht) VALUES ("2", "Weiblich");


CREATE TABLE rechte (
	PK_Rechte_ID int NOT NULL PRIMARY KEY, 
	Rechte VARCHAR(255)
);

INSERT INTO rechte (PK_Rechte_ID, Rechte) VALUES ("1", "Darf im Backend");
INSERT INTO rechte (PK_Rechte_ID, Rechte) VALUES ("2", "Darf nicht im Backend");


CREATE TABLE benutzer (
	PK_Benutzer_ID int AUTO_INCREMENT NOT NULL PRIMARY KEY, 
	Benutzername VARCHAR(255), 
	Passwort VARCHAR(255), 
	Geburtsdatum DATE, 
	FK_Geschlecht_ID int NOT NULL,
	FOREIGN KEY (FK_Geschlecht_ID) REFERENCES geschlecht(PK_Geschlecht_ID), 
	FK_Rechte_ID int NOT NULL,
	FOREIGN KEY (FK_Rechte_ID) REFERENCES rechte(PK_Rechte_ID)
);

INSERT INTO benutzer (Benutzername, Passwort, Geburtsdatum, FK_Geschlecht_ID, FK_Rechte_ID) VALUES ("admin", "admin", "2000-01-01", "1", "1");
INSERT INTO benutzer (Benutzername, Passwort, Geburtsdatum, FK_Geschlecht_ID, FK_Rechte_ID) VALUES ("TestUser", "test", "2000-01-01", "1", "2");


CREATE TABLE events (
	PK_Event_ID int AUTO_INCREMENT NOT NULL PRIMARY KEY,
	Titel VARCHAR(255),
	Datum DATE,
	Uhrzeit TIME,
	Beschreibung VARCHAR(1500),
	Bild VARCHAR(255),
	Straße VARCHAR(255),
	Ort VARCHAR(255)
);

INSERT INTO events (Titel, Datum, Uhrzeit, Beschreibung, Bild, Straße, Ort) VALUES ("Paintball Event", "2020-01-31", "12:00:00", "Wir spielen Paintball.", "Images/1.jpg", "Engerthstraße 1", "1020 Wien");


CREATE TABLE ZwischentabelleBE (
	FK_Benutzer_ID int NOT NULL,
	FOREIGN KEY(FK_Benutzer_ID) REFERENCES benutzer(PK_Benutzer_ID),
	FK_Event_ID int NOT NULL,
	FOREIGN KEY(FK_Event_ID) REFERENCES events(PK_Event_ID)
);