-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 05, 2019 at 10:22 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eplaner`
--

-- --------------------------------------------------------

--
-- Table structure for table `benutzer`
--

CREATE TABLE `benutzer` (
  `PK_Benutzer_ID` int(11) NOT NULL,
  `Benutzername` varchar(255) DEFAULT NULL,
  `Passwort` varchar(255) DEFAULT NULL,
  `Geburtsdatum` date DEFAULT NULL,
  `FK_Geschlecht_ID` int(11) DEFAULT NULL,
  `FK_Rechte_ID` int(11) DEFAULT NULL,
  `FK_Event_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `benutzer`
--

INSERT INTO `benutzer` (`PK_Benutzer_ID`, `Benutzername`, `Passwort`, `Geburtsdatum`, `FK_Geschlecht_ID`, `FK_Rechte_ID`, `FK_Event_ID`) VALUES
(1, 'admin', 'admin', '1990-01-01', 1, 1, 1),
(2, 'TestUser', 'test', '2019-10-02', 1, 2, 1),
(3, 'sdfvsadv', 'asfaewfa', '1278-12-12', 1, 2, NULL),
(4, 'vgbhnjm', 'gvbhnjmk', '2018-03-12', 1, 2, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `PK_Event_ID` int(11) NOT NULL,
  `Titel` varchar(255) DEFAULT NULL,
  `Datum` date DEFAULT NULL,
  `Uhrzeit` time DEFAULT NULL,
  `Beschreibung` varchar(1500) DEFAULT NULL,
  `Bild` varchar(255) DEFAULT NULL,
  `Ort` varchar(255) DEFAULT NULL,
  `Straße` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`PK_Event_ID`, `Titel`, `Datum`, `Uhrzeit`, `Beschreibung`, `Bild`, `Ort`, `Straße`) VALUES
(1, 'Paintball Event', '2020-01-20', '16:30:00', 'Wir gehen Paintball spielen am 20.06.2019, alle unter 16 Jährigen brauchen die Erlaubnis ihrer Eltern.', 'Images\\1.jpg', '2320 Schwechat', 'Himbergerstraße 19'),
(3, 'test', '2019-12-12', '12:23:00', 'asdfawecd', 'Images/d.png', '2320 Schwechat', 'Himbergerstraße'),
(4, 'test', '2019-12-22', '22:23:00', 'Testevent', 'Images/1.jpg', '2320 Schwechat', 'Himbergerstraße');

-- --------------------------------------------------------

--
-- Table structure for table `geschlecht`
--

CREATE TABLE `geschlecht` (
  `PK_Geschlecht_ID` int(11) NOT NULL,
  `Geschlecht` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `geschlecht`
--

INSERT INTO `geschlecht` (`PK_Geschlecht_ID`, `Geschlecht`) VALUES
(1, 'Männlich'),
(2, 'Weiblich');

-- --------------------------------------------------------

--
-- Table structure for table `rechte`
--

CREATE TABLE `rechte` (
  `PK_Rechte_ID` int(11) NOT NULL,
  `Rechte` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rechte`
--

INSERT INTO `rechte` (`PK_Rechte_ID`, `Rechte`) VALUES
(1, 'Darf im Backend'),
(2, 'Darf nicht im Backend');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `benutzer`
--
ALTER TABLE `benutzer`
  ADD PRIMARY KEY (`PK_Benutzer_ID`),
  ADD KEY `FK_Geschlecht_ID` (`FK_Geschlecht_ID`),
  ADD KEY `FK_Rechte_ID` (`FK_Rechte_ID`),
  ADD KEY `FK_Event_ID` (`FK_Event_ID`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`PK_Event_ID`);

--
-- Indexes for table `geschlecht`
--
ALTER TABLE `geschlecht`
  ADD PRIMARY KEY (`PK_Geschlecht_ID`);

--
-- Indexes for table `rechte`
--
ALTER TABLE `rechte`
  ADD PRIMARY KEY (`PK_Rechte_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `benutzer`
--
ALTER TABLE `benutzer`
  MODIFY `PK_Benutzer_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `PK_Event_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `benutzer`
--
ALTER TABLE `benutzer`
  ADD CONSTRAINT `benutzer_ibfk_1` FOREIGN KEY (`FK_Geschlecht_ID`) REFERENCES `geschlecht` (`PK_Geschlecht_ID`),
  ADD CONSTRAINT `benutzer_ibfk_2` FOREIGN KEY (`FK_Rechte_ID`) REFERENCES `rechte` (`PK_Rechte_ID`),
  ADD CONSTRAINT `benutzer_ibfk_3` FOREIGN KEY (`FK_Event_ID`) REFERENCES `events` (`PK_Event_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
