<!DOCTYPE html>
<html lang="de" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>delete</title>

  </head>
  <body>
<?php	
	$pdo = new PDO("mysql: host=localhost; dbname=eplaner;charset=utf8","root", "");
	$statement = $pdo->prepare("DELETE FROM events WHERE PK_Event_ID ='$_GET[id]'");
	$statement->execute();
	
	header("refresh:1; url=deletebtn.php");
?>

  
  
  </body>
</html>