﻿<html lang="de" dir="ltr">
	<head>
		<title>Events</title>
		<meta charset="UTF-8">
	</head>
		<body>
		
		<?php
			
		
		$pdo = new PDO("mysql: host=localhost; dbname=eplaner;charset=utf8","root", "");
		$statement = $pdo->prepare("SELECT * FROM events;");
		$statement->execute();
		?>
		
		<table align="center" border=1>
			<tr>
				<th> Titel </th>
				<th> Datum </th>
				<th> Beschreibung </th>
				<th> Bearbeiten </th>
				<th> L&ouml;schen </th>
			</tr>
			<?php
				while (($record = $statement->fetch(PDO::FETCH_ASSOC)) != FALSE) {
					echo "<tr>";
					echo "<td>".$record['Titel']."</td>";
					echo "<td>".$record['Datum']."</td>";
					echo "<td>".$record['Beschreibung']."</td>";
					echo "<td><a href=edit_index.php?id=".$record['PK_Event_ID'].">Bearbeiten</a></td>";
					echo "<td><a href=delete.php?id=".$record['PK_Event_ID'].">L&ouml;schen</a></td>";
				}
					
			?>					
				


		
		
		</table>			
  </body>
</html>