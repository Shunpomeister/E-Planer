<?php
 session_start();  

if (!isset($_SESSION["eingeloggt"]) || $_SESSION["eingeloggt"] != TRUE) {
    header ("Location: login.php");
}
?>