<!DOCTYPE html>
<html lang="de" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login</title>
    <style>
    img	{
        margin:0px auto;
        width:600px;
        height:180px;
        display: block;
        margin-left: auto;
        margin-right: auto;
      }
	#login	{
      position: absolute;
  		left: 50%;
  		margin-top: -125px;
  		margin-left: -125px;
  		top: 50%;
  		width:250px;
  		height:250px;
  		background-color:#FFEFEF;
  		border:solid 2px;
      text-align:center;
      font-family: cursive;
		}
  #formular	{
      position: absolute;
      left: 10px;
      top: 50px;
      right: 10px;
      bottom: 10px;
      background-color:#FFEFEF;
      border:solid 2px;
      text-align:center;
    }
  #footer	{
        background-color: #FFB732;
        color: #000;
        font-size:12pt;
        position: fixed;
        left: 0px;
        bottom: 0px;
        width: 100%;
        height: 20px;
        text-align:right;
  	}
		</style>
  </head>
	<body style="background-image: url('../Images/Paris.jpg');background-size: cover; background-repeat: no repeat; background-attachment: fixed;">

    <a href="../Startseite.php"><img src="../Images/logo.png"></a>

    <div id="login">Login
    <div id="formular">
	<form action="login.php" method="POST">
			Benutzername:
			<input type ="text" name="user"/> </br>
			</br>
			Passwort:
			<input type ="password" name="pw"/> </br>
			</br>

			<input type ="submit" name="button" value="Login"/>
		</form>
	</div></div>
    <div id="footer">Kontakt: Tel./Nr.: +436604337890 / E-Mail: <a href="mailto:Eplaner.hilfe@gmail.com?">eplaner.hilfe@gmail.com</a></div>
  </body>
</html>
