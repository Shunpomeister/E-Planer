<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Registrierungsformular</title>
</head>
<body>
    <form method="POST">
        <p>Benutzername: <input type="text" name="benutzername"></p>
        <p>Passwort: <input type="password" name="passwort"></p>
        <p>Geburtsdatum: <input type="date" name="geburtsdatum"></p>
        <p>Geschlecht: 
            <select name="geschlecht">
                <?php
                    $pdo = new PDO("mysql: host=localhost; dbname=eplaner", "root", "");
                    $sql = "SELECT * FROM geschlecht;";
                    $statement = $pdo->prepare($sql);
                    $statement->execute();
                        while(($geschlecht = $statement->fetch(PDO::FETCH_ASSOC)) != FALSE) {
                            echo "<option value=\"" . $geschlecht["PK_Geschlecht_ID"] . "\">" . $geschlecht["Geschlecht"] . "</option>";
                        }
                ?>
            </select>
        </p>
        <input type="submit" name="button" value="Registrieren">
    </form>
    <?php
        if(isset($_POST["benutzername"]) && isset($_POST["passwort"]) && isset($_POST["geburtsdatum"]) && isset($_POST["geschlecht"])) {
            $benutzername = htmlspecialchars($_POST["benutzername"]);
            $passwort = htmlspecialchars($_POST["passwort"]);
            $geburtsdatum = htmlspecialchars($_POST["geburtsdatum"]);
            $geschlecht = htmlspecialchars($_POST["geschlecht"]);
            $pdo = new PDO("mysql: host=localhost; dbname=eplaner", "root", "");
            $sql = "INSERT INTO benutzer (Benutzername, Passwort, Geburtsdatum, FK_Geschlecht_ID, FK_Rechte_ID) VALUES ('$benutzername', '$passwort', '$geburtsdatum', '$geschlecht', '2');";
            $statement = $pdo->prepare($sql);
            $statement->execute();
                if($statement != FALSE) {
                    header("Location: startseite.php");
                }
        }
    ?>
</body>
</html>