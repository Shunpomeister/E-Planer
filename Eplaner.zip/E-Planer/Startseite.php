<!DOCTYPE html>
<html lang="de" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Startseite</title>
    <style>

    #logo	{
		margin:0px auto;
		width:0px;
		height:0px;
		background-color:#FFF;
		float: left;
		width: 50%;
		top: 0px;
	}
	#content	{
      position: absolute;
		  left: 25px;
      top: 200px;
			width: 97%;
      height: auto;
      font-size: 25pt;
	}
  #header {
      position: relative;
      width: 100%;
      height: 30px;
      background-color: #FFA500;
  }
  #registerbtn{
    position: absolute;
    right: 10px;
    bottom: 0px;
    text-align: center;
    font-size: 16px;
  }
  #loginbtn {
    position: absolute;
    right: 75px;
    bottom: 0px;
    text-align: center;
    font-size: 16px;
    }
  #kalender {
    position: absolute;
    top: 91px;
    left: 0%;
    width: 25%;
    background-color: #FFA500;
    }
  #inhalt	{
      position: absolute;
      left: 25%;
      width: 75%;
      height: auto;
      background-color: #FFA500;
		}
  #footer	{
        background-color: #FFB732;
        color: #000;
        font-size:12pt;
        position: fixed;
        left: 0px;
        bottom: 0px;
        width: 100%;
        height: 20px;
        text-align:right;
  	}
  #event {

        color: #000;
        font-size:12pt;
        position: absolute;
        left: 10px;
        top: 9px;
        width: 99%;
        text-align:right;
    }
  .eventbox {
        background-color: rgba(255, 255, 255, 0.5);
        color: #000;
        font-size:12pt;
        position: relative;
        top: 1px;
        width: 95%;
        text-align:left;
        padding: 5px;
    }

    .eventboxwrapper {
        padding-bottom: 10px;
    }
    #teilnehmbtn{
        position: absolute;
        right: 10px;
        bottom: 0px;
        text-align: center;
        font-size: 16px;
    }
    #nichtteilnehmbtn {
        position: absolute;
        right: 130px;
        bottom: 0px;
        text-align: center;
        font-size: 16px;
      }

		</style>
  </head>
      <div id="logo"><a href="Startseite.php"><img src="Images/logo.png"></a></div>

  <body style="background-image: url('Images/Paris.jpg');background-size: cover; background-repeat: no repeat; background-attachment: fixed;">
    <div id="content">

      <div id="header"><h6>Top Events</h6>
        <div id="loginbtn"><a href="Login/Loginseite.php">Login</a></div>
        <div id="registerbtn"><a href="Register/Registerseite.php">Register</a></div>
      </div>

      <div id="kalender">kalenderkalenderkalender
        kalenderkalenderkalender
        kalenderkalenderkalender
        kalenderkalenderkalender
        kalenderkalenderkalender</div>
      <div id="inhalt">
        <div id="event">
                  <?php
                      $pdo = new PDO("mysql: host=localhost; port=3306; charset=utf8; dbname=eplaner","root", "");
                      $statement = $pdo->prepare("SELECT * FROM events;");
                      $statement->execute();

                      while (($record = $statement->fetch(PDO::FETCH_ASSOC)) != FALSE) {

                          echo "<div class=\"eventboxwrapper\">";
                          echo "<div class=\"eventbox\">";
                          echo $record["Bild"] . "</br>";
                          echo $record["Titel"] . "</br>";
                          echo $record["Datum"] . "</br>";
                          echo $record["FK_Ort_ID"] . "</br>";
                          echo $record["Beschreibung"] . "</br>";
                          echo "<div id=\"teilnehmbtn\">";
                          echo "nicht teilnehmen";
                          echo "</div>";
                          echo "<div id=\"nichtteilnehmbtn\">";
                          echo "teilnehmen";
                          echo "</div>";
                          echo "</div>";
                          echo "</div>";
                    }
                 ?>
          </table>
        </div>

      </div>
    </div>
    <div id="footer">E-Mail: <a href="mailto:Eplaner.hilfe@gmail.com?">eplaner.hilfe@gmail.com</a></div>
  </body>
</html>
