<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Anmelden</title>
</head>
<body>
    <?php
        if(isset($_POST["benutzername"]) && isset($_POST["passwort"])) {
            $benutzername = $_POST["benutzername"];
            $passwort = $_POST["passwort"];
            $pdo = new PDO("mysql: host:localhost; dbname=eplaner", "root", "");
            $sql = "SELECT * FROM benutzer WHERE Benutzername = '$benutzername' AND Passwort = '$passwort';";
            $statement = $pdo->prepare($sql);
                if($statement->execute()) {
                    if($statement->fetch(PDO::FETCH_ASSOC) != FALSE) {
                        $_SESSION["logged_in"] = true;
                        header("Location: startseite.ang.php");
                    } else {
                        $_SESSION["logged_in"] = false;
                        header("Location: anmeldeformular.php");
                    }
                } else {
                    echo "Es wurde weder Username noch Password geschickt!";
                }
        }
    ?>
</body>
</html>