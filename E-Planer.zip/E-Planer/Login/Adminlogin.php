<!DOCTYPE html>
<html lang="de" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Startseite</title>
    <style>

    #logo	{
		margin:0px auto;
		width:0px;
		height:0px;
		background-color:#FFF;
		float: left;
		width: 50%;
		top: 0px;
	}
	#content	{
      position: absolute;
		  left: 25px;
      top: 200px;
			width: 97%;
      height: auto;
      font-size: 25pt;
	}
  #header {
      position: relative;
      width: 100%;
      height: 30px;
      background-color: #FFA500;
  }
  #registerbtn{
    position: absolute;
    right: 10px;
    bottom: 0px;
    text-align: center;
    font-size: 16px;
  }
  #loginbtn {
    position: absolute;
    right: 75px;
    bottom: 0px;
    text-align: center;
    font-size: 16px;
    }
  #kalender {
    position: absolute;
    top: 90px;
    left: 0%;
    width: 25%;
    background-color: #FFA500;
    }
  #inhalt	{
      position: absolute;
      left: 25%;
      width: 75%;
      height: auto;
      background-color: #FFA500;
		}
  #footer	{
        background-color: #FFB732;
        color: #000;
        font-size:12pt;
        position: fixed;
        left: 0px;
        bottom: 0px;
        width: 100%;
        height: 20px;
        text-align:right;
  	}
  #event {
        color: #000;
        font-size:12pt;
        position: absolute;
        left: 13px;
        top: 9px;
        width: 98%;
        height: auto;
        text-align:right;
    }
  .eventbox {
        background-color: #FFF;
        color: #000;
        font-size:12pt;
        position: absolute;
        left: 13px;
        top: 9px;
        width: 98%;
        text-align:right;
    }

		</style>
  </head>

  <?php
  if (isset($_POST["benutzername"]) && isset($_POST["passwort"]))   {

        $benutzername = $_POST["benutzername"];
        $passwort = $_POST["passwort"];

        $pdo = new PDO("mysql: host=localhost; dbname=eplaner", "root", "");
        $sql = "SELECT * FROM benutzer WHERE Benutzer = :benutzername AND Passwort = :passwort;";
        $statement = $pdo->prepare($sql);
        $statement->bindParam(":benutzername", $benutzername);
        $statement->bindParam(":passwort", $passwort);

        if($statement->execute()) {

          if ($statement->fetch(PDO::FETCH_ASSOC) != FALSE) {

            $_SESSION["logged_in"] = true;
            echo "<a href=\"true.php\">Weiter zum geschützten Bereich</a>";
          } else {

            $_SESSION["logged_in"] = false;
            echo "Die Zugangsdaten sind falsch!";
          }
        }


      } else {

        echo "Es wurde weder Benutzername noch Passwort geschickt!";
      }



  ?>
      <div id="logo"><a href="Startseite.php"><img src="Images/logo.png"></a></div>

  <body style="background-image: url('Images/Paris.jpg');background-size: cover; background-repeat: no repeat; background-attachment: fixed;">
    <div id="content">

      <div id="header"><h6>Admin</h6>
        <div id="loginbtn"><a href="Login/Loginseite.php">Login</a></div>
        <div id="registerbtn"><a href="Register/Registerseite.php">Register</a></div>
      </div>

      <div id="kalender">kalenderkalenderkalender
        kalenderkalenderkalender
        kalenderkalenderkalender
        kalenderkalenderkalender
        kalenderkalenderkalender</div>
      <div id="inhalt">
        <div id="event">
          <table>
                  <?php
                      $pdo = new PDO("mysql: host=localhost; port=3306; dbname=eventplaner","root", "");
                      $statement = $pdo->prepare("SELECT * FROM events;");
                      $statement->execute();

                      while (($record = $statement->fetch(PDO::FETCH_ASSOC)) != FALSE) {

                        echo "<div class=\"eventbox\">";
                        echo "<tr><td>" . $record["eventname"] . "</td></tr>";
                        echo "<tr><td>" . $record["datum"] .  "</td></tr>";
                        echo "<tr><td>" . $record["ort"] . "</td></tr>";
                        echo "<tr><td>" . $record["info"] . "</td></tr>";
                        echo "</div>";
                  }
                 ?>
          </table>
        </div>

      </div>
    </div>
    <div id="footer">Kontakt: Tel./Nr.: +436604337890 / E-Mail: <a href="mailto:Eplaner.hilfe@gmail.com?">eplaner.hilfe@gmail.com</a></div>
  </body>
</html>
