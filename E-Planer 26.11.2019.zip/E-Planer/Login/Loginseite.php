<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Anmeldeformular</title>
    <style>
    body {
      background-color: #01054C;
    }
    img	{
        margin:0px auto;
        width:600px;
        height:180px;
        display: block;
        margin-left: auto;
        margin-right: auto;
      }
    #formular {
      position: relative;
      width: 15%;
      left:40%;
      top: 30px;
      text-align: center;
      background-color: #FFA500;
      background-color:#FFA500;
      border-radius:40px;
      border:2px solid #FFA500;
      display:inline-block;
      color:#FFF;
      padding:17px 30px;
      text-decoration:none;
      text-shadow:0px 1px 12px #2f6627;
    }
    .textfeld {
      background-color:#FFA500;
      border-radius:40px;
      border:2px solid #FFF;
      display:inline-block;
      color:#FFF;
      font-family:Verdana;
      font-size:14px;
      font-weight:bold;
      padding:6px 12px;
    }
    .btn {
      background-color:#FFA500;
      border-radius:40px;
      border:2px solid #FFF;
      display:inline-block;
      color:#FFF;
      font-family:Verdana;
      font-size:12px;
      font-weight:bold;
      padding:13px 22px;
      text-shadow:0px 1px 12px #2F6627;
      cursor:pointer;
    }
    #footer	{
        background-color: #FFB732;
        color: #000;
        font-size:12pt;
        position: fixed;
        left: 0px;
        bottom: 0px;
        width: 100%;
        height: 20px;
        text-align:right;
  	}
    a {
      color: #FFF;
      font-size: 10pt;
    }
		</style>
</head>
<body style="background-image: url('../Images/Paris.jpg');background-size: cover; background-repeat: no repeat; background-attachment: fixed;">

    <a href="../Startseite.php"><img src="../Images/logo.png"></a>

    <div id="formular">
      <h2>Login</h2>
    <form action="anmelden.php" method="POST">
        <p>Benutzername: <input type="text" name="benutzername" class="textfeld"></p>
        <p>Passwort: <input type="password" name="passwort" class="textfeld"></p>
        <input type="submit" name="button" value="Anmelden" class="btn"><br><br>
        <a href="../Register/Registerseite.php">Noch nicht Registriert?</a>
    </form>
    </div>
    <div id="footer">Kontakt: Tel./Nr.: +436604337890 / E-Mail: <a href="mailto:Eplaner.hilfe@gmail.com?">eplaner.hilfe@gmail.com</a></div>
</body>
</html>
