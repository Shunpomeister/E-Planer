<?php
session_start();
require_once("Login/anmelden.inc.php")
 ?>
 <!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
    	$pdo = new PDO("mysql: host=localhost; dbname=eplaner;charset=utf8","root", "");
    	$statement = $pdo->prepare("DELETE FROM events WHERE PK_Event_ID = :eventid");
      $statement->bindParam(":eventid" , $_GET["eventid"]);
    	$statement->execute();

    	header("refresh:1; url=Adminstartseite.php");
    ?>
  </body>
</html>
