<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Registrierungsformular</title>
    <style>
    body {
      background-color: #01054C;
    }
			#content	{
        position: absolute;
        left: 2%;
        right: 2%;
        top: 28%;
        height: auto;
      }
      #header {
        position: relative;
        width: 100%;
        background-color: #FFA500;
        text-align:center;
      }
      img	{
          margin:0px auto;
          width:600px;
          height:180px;
          display: block;
          margin-left: auto;
          margin-right: auto;
        }
      #logout{
        position: absolute;
        right: 10px;
        bottom: 0px;
        text-align: center;
        font-size: 16px;
      }

      #hinzufügen {
        position: absolute;
        right: 75px;
        bottom: 0px;
        text-align: center;
        font-size: 16px;
      }
      #formular {
        position: relative;
        width: 25%;
		left:35%;
        top: 30px;
        text-align: center;
        background-color: #FFA500;
      	background-color:#FFA500;
      	border-radius:40px;
      	border:2px solid #FFA500;
      	display:inline-block;
      	color:#FFF;
      	padding:17px 30px;
      	text-decoration:none;
      	text-shadow:0px 1px 12px #2f6627;
      }
      .textfeld {
      	background-color:#FFA500;
      	border-radius:40px;
      	border:2px solid #FFF;
      	display:inline-block;
      	color:#FFF;
      	font-family:Verdana;
      	font-size:14px;
      	font-weight:bold;
      	padding:6px 12px;
      }
      .beschreibung {
      	background-color:#FFA500;
      	border-radius:40px;
      	border:2px solid #FFF;
      	display:inline-block;
      	color:#FFF;
      	font-family:Verdana;
      	font-size:14px;
      	font-weight:bold;
      	padding:6px 12px;
        height: 100px;
        width: 330px;
      }
      .btn {
      	background-color:#FFA500;
      	border-radius:40px;
      	border:2px solid #FFF;
      	display:inline-block;
      	color:#FFF;
      	font-family:Verdana;
      	font-size:12px;
      	font-weight:bold;
      	padding:13px 22px;
      	text-shadow:0px 1px 12px #2F6627;
      	cursor:pointer;
      }

      #footer	{
          background-color: #FFB732;
          color: #000;
          font-size:12pt;
          position: fixed;
          left: 0px;
          bottom: 0px;
          width: 100%;
          height: 20px;
          text-align:right;
    	}
      a {
        color: #FFF;
        font-size: 10pt;
      }
	</style>
</head>
<body style="background-image: url('Paris.jpg');background-size: cover; background-repeat: no repeat; background-attachment: fixed;">
  <a href="../startseite.php"><img src="../Images/logo.png"></a>
  <div id="content">
      <div id="formular">
    <form method="POST">
        <h2>Registrieren</h2>
        <p>Benutzername: <br> <input type="text" name="benutzername" class="textfeld"></p>
        <p>Passwort: <br> <input type="password" name="passwort" id="myInput" maxlength="40" required class="textfeld"><input type="checkbox" onclick="myFunction()"></p>
        <p>
        <script>
    			function myFunction() {
    				var x = document.getElementById("myInput");
    				if (x.type === "password") {
    					x.type = "text";
    				} else {
    					x.type = "password";
    				}
    			}
         </script>
        </p>
        <p>Geburtsdatum: <input type="date" name="geburtsdatum" class="textfeld"></p>
        <p>Geschlecht:
            <select name="geschlecht" class="textfeld">
                <?php
                    $pdo = new PDO("mysql: host=localhost; charset=UTF8; dbname=eplaner", "root", "");
                    $sql = "SELECT * FROM geschlecht;";
                    $statement = $pdo->prepare($sql);
                    $statement->execute();
                        while(($geschlecht = $statement->fetch(PDO::FETCH_ASSOC)) != FALSE) {
                            echo "<option value=\"" . $geschlecht["PK_Geschlecht_ID"] . "\">" . $geschlecht["Geschlecht"] . "</option>";
                        }
                ?>
            </select>
        </p>
        <input type="submit" name="button" value="Registrieren" class="btn"><br><br>
        <a href="../Login/Loginseite.php">Schon angemeldet?</a>
    </form>
    </div>
    </div>
    <?php
        if(isset($_POST["benutzername"]) && isset($_POST["passwort"]) && isset($_POST["geburtsdatum"]) && isset($_POST["geschlecht"])) {
            $benutzername = htmlspecialchars($_POST["benutzername"]);
            $passwort = htmlspecialchars($_POST["passwort"]);
            $geburtsdatum = htmlspecialchars($_POST["geburtsdatum"]);
            $geschlecht = htmlspecialchars($_POST["geschlecht"]);
            $pdo = new PDO("mysql: host=localhost; dbname=eplaner", "root", "");
            $sql = "INSERT INTO benutzer (Benutzername, Passwort, Geburtsdatum, FK_Geschlecht_ID, FK_Rechte_ID) VALUES ('$benutzername', '$passwort', '$geburtsdatum', '$geschlecht', '2');";
            $statement = $pdo->prepare($sql);
            $statement->execute();
                if($statement != FALSE) {
                    header("Location: ../startseite.php");
                }
        }
    ?>
    <div id="footer">Kontakt: Tel./Nr.: +436604337890 / E-Mail: <a href="mailto:Eplaner.hilfe@gmail.com?">eplaner.hilfe@gmail.com</a></div>
</body>
</html>
